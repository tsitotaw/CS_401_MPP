package dataaccess;

import java.util.HashMap;

import business.*;

public interface DataAccess { 
	public HashMap<String,Book> readBooksMap();
	public HashMap<String,Author> readAuthorsMap();
	public HashMap<String,CheckoutRecordEntry> readCheckoutRecordEntriesMap();
	public HashMap<String, CheckoutRecord> readCheckoutRecordsMap();
	public HashMap<String,User> readUserMap();
	public HashMap<String, BookCopy> readBookCopyMap();
	public HashMap<String, LibraryMember> readMemberMap();
	public void saveNewMember(LibraryMember member);
	public void saveNewAuthor(Author author);
	public void saveBookCopy(BookCopy copy);
	public void saveNewCheckoutRecordEntry(CheckoutRecordEntry entry);
	public void saveNewBook(Book book);
	public void saveNewCheckoutRecord(CheckoutRecord entry);
}
