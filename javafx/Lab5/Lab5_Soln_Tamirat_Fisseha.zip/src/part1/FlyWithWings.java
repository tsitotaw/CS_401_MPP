package part1;

public class FlyWithWings implements FlyBehavior {
	public void ﬂy() {
		System.out.println("fly with wings");
	}
}
