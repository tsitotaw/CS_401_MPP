
Student Name 					=> Tamirat Fisseha Sitotaw

Student Id						=> 613437

Problem Questions addressed		=> Problem 1
								=> Problem 2
								=> Problem 3
								=> Problem 4
								
								
								
Comment For Professor
	=> For Problem 3, I tackled the stream pipeline exception using two helper classes
		1 -> a generic predicate based exception interface 
		2 -> a lambda library that will consume the predicate interface and move the pipeline to this library from the actual class
		
	=> The Problem3 class will use the new lambda library to get the winner name
	=> Hope you appreciate the work and give me a bonus :)