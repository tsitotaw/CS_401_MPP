package librarysystem;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.List;

import javax.swing.*;

import business.ControllerInterface;
import business.SystemController;

public class LibrarySystem extends JFrame implements LibWindow {
	
	private static final long serialVersionUID = 3512507622974095446L;
	ControllerInterface ci = new SystemController();
	public final static LibrarySystem INSTANCE = new LibrarySystem();
	
	JPanel mainPanel;
	JMenuBar menuBar;
	JMenuBar menuBar2;
	JMenu options;
	JMenu addMenu;
	JMenu bookCheckoutMenu;
	JMenu helpMenu;
	JMenuItem allBookIds, allMemberIds;
	JMenuItem newBook, newMember, newBookCopy, newAuthor;
	JMenuItem aboutMenuItem, logoutMenuItem;
	
	static AddNewBookWindow addBookWindow = new AddNewBookWindow();
	static AddNewBookCopyWindow addBookCopyWindow = new AddNewBookCopyWindow();
	static AddAuthorWindow addAuthorWindow = new AddAuthorWindow();
	static AddNewMemberWindow addMemberWindow = new AddNewMemberWindow();
	static CheckoutBookWindow checkoutBook = new CheckoutBookWindow();
	static LoginWindow login = new LoginWindow();
	
	String pathToImage;
	private boolean isInitialized = false;
	private JMenuItem bookCheckout;

	@SuppressWarnings("unused")
	private static LibWindow[] allWindows = { 
			LibrarySystem.INSTANCE,
			 addBookWindow,
			 addMemberWindow,
			AllMemberIdsWindow.INSTANCE, 
			checkoutBook 
	};

	public static void hideAllWindows() {

//		for (LibWindow frame : allWindows) {
//			frame.setVisible(false);
//			LibrarySystem.INSTANCE.dispose();
//		}
	}

	@SuppressWarnings("static-access")
	LibrarySystem() {
        this.setExtendedState(this.getExtendedState() | this.MAXIMIZED_BOTH);
	}

	public void init() {
		formatContentPane();
		setPathToImage();
		insertSplashImage();

		createMenus();
		isInitialized = true;
	}

	private void formatContentPane() {
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(1, 1));
		getContentPane().add(mainPanel);
	}

	private void setPathToImage() {
		String currDirectory = System.getProperty("user.dir");
		pathToImage = currDirectory + "/src/librarysystem/library-big.jpg";
	}

	private void insertSplashImage() {
		ImageIcon image = new ImageIcon(pathToImage);
		mainPanel.add(new JLabel(image));
	}

	private void createMenus() {

		menuBar = new JMenuBar();
		menuBar.setBorder(BorderFactory.createRaisedBevelBorder());
		addNewMenuItems();
		checkoutBook();
		addHelpMenuItems();
		setJMenuBar(menuBar);
		customizeMenuBar();
	}
	
	//Give access based on who is logged in
	private void customizeMenuBar() {
		switch(SystemController.currentAuth) {
			case LIBRARIAN:
				addMenu.setEnabled(false);
				break;
				
			case ADMIN:
				bookCheckoutMenu.setEnabled(false);
				break;
		default:
			break;
		}
	}

	private void checkoutBook() {
		bookCheckoutMenu = new JMenu("Checkout");
		menuBar.add(bookCheckoutMenu);

		bookCheckout = new JMenuItem("Book");
		bookCheckout.addActionListener(new CheckoutBookListener());
		bookCheckoutMenu.add(bookCheckout);
		
	}
	private void addHelpMenuItems() {
		helpMenu = new JMenu("Help");
		menuBar.add(helpMenu);

		aboutMenuItem = new JMenuItem("About");
		//The commented line below will be implemented later
		aboutMenuItem.addActionListener(new AboutListener());
		logoutMenuItem = new JMenuItem("Log out");
		logoutMenuItem.addActionListener(new LogoutListener());

		helpMenu.add(aboutMenuItem);
		helpMenu.add(logoutMenuItem);
	}

	private void addNewMenuItems() {
		addMenu = new JMenu("Manage");
		menuBar.add(addMenu);
		newBook = new JMenuItem("Book");
		newBookCopy = new JMenuItem("Book Copy");
		newAuthor = new JMenuItem("Author");
		newBook.addActionListener(new AddNewBookListener());
		newBookCopy.addActionListener(new AddNewBookCopyListener());
		newAuthor.addActionListener(new AddNewAuthorListener());
		newMember = new JMenuItem("Member");
		newMember.addActionListener(new AddNewMemberListener());
		addMenu.add(newBook);
		addMenu.add(newBookCopy);
		addMenu.add(newAuthor);
		addMenu.add(newMember);
	}

	class AddNewBookListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();

			//AddNewBookWindow.INSTANCE.init();

			List<String> ids = ci.allBookIds();
			Collections.sort(ids);
			StringBuilder sb = new StringBuilder();
			for (String s : ids) {
				sb.append(s + "\n");
			}
			//System.out.println(sb.toString());
			
			Util.centerFrameOnDesktop(addBookWindow);
			addBookWindow.setVisible(true);

		}

	}
	class AboutListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(new JFrame(), "Library Management System. \n CS-401 MPP @ Oct 2021 \n Developed by: \n\t\t 1 - Obsa Taere \n\t\t 2 - Bulelani Mlindelwa\n\t\t 3 - Tamirat Fisseha\n", "Message",
					JOptionPane.INFORMATION_MESSAGE);
		}

	}
	class AddNewBookCopyListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();
			//AllBookIdsWindow.INSTANCE.setData(sb.toString());
			//AddNewBookWindow.INSTANCE.pack();
			// AllBookIdsWindow.INSTANCE.setSize(660,500);
			Util.centerFrameOnDesktop(addBookCopyWindow);
			addBookCopyWindow.setVisible(true);
			INSTANCE.dispose();

		}

	}
	class AddNewAuthorListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();
			//AllBookIdsWindow.INSTANCE.setData(sb.toString());
			//AddNewBookWindow.INSTANCE.pack();
			// AllBookIdsWindow.INSTANCE.setSize(660,500);
			Util.centerFrameOnDesktop(addAuthorWindow);
			addAuthorWindow.setVisible(true);
			INSTANCE.dispose();

		}

	}
	class CheckoutBookListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();

			List<String> ids = ci.allBookIds();
			Collections.sort(ids);
			StringBuilder sb = new StringBuilder();
			for (String s : ids) {
				sb.append(s + "\n");
			}
			System.out.println(sb.toString());
			
			Util.centerFrameOnDesktop(checkoutBook);
			
			checkoutBook.setVisible(true);

		}

	}

	class AddNewMemberListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();

			LibrarySystem.hideAllWindows();
			//AllBookIdsWindow.INSTANCE.init();

			List<String> ids = ci.allMemberIds();
			Collections.sort(ids);
			StringBuilder sb = new StringBuilder();
			for (String s : ids) {
				sb.append(s + "\n");
			}
			System.out.println(sb.toString());
			
			Util.centerFrameOnDesktop(addMemberWindow);
			addMemberWindow.setVisible(true);

		}

	}
	
	class LogoutListener implements ActionListener {
		SystemController sc = new SystemController();

		@Override
		public void actionPerformed(ActionEvent e) {
			LibrarySystem.hideAllWindows();
			sc.logout();
			//SystemController.currentAuth = null;
			
			//AllBookIdsWindow.INSTANCE.setData(sb.toString());
			//AddNewBookWindow.INSTANCE.pack();
			// AllBookIdsWindow.INSTANCE.setSize(660,500);
			Util.centerFrameOnDesktop(addBookWindow);
			new LoginWindow().setVisible(true);
			INSTANCE.dispose();

		}

	}

	@Override
	public boolean isInitialized() {
		return isInitialized;
	}

	@Override
	public void isInitialized(boolean val) {
		isInitialized = val;

	}

}
