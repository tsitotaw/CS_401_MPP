package librarysystem;

import business.Book;
import business.BookCopy;
import business.SystemController;

import javax.swing.*;
import java.sql.Connection;
import java.util.HashMap;

public class AddNewBookCopyWindow extends JFrame implements LibWindow {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	static Connection c;
    static String ISBN, SID;
    private Book selectedBook;
    private String selectedMemberId;
    private static String[] COLUMNS = { "ISBN", "Copy Number", "Is Available"};
    private static Object[][] ROWS_EMPTY = {{}};
    private SystemController controller = new SystemController();
    public AddNewBookCopyWindow() {
        initComponents();
        setTitle("Check Out Book");
        setResizable(false);
        setLocationRelativeTo(null);
        jTable1.setEnabled(false);
        ISBN = "";
        SID = "";
        cmbIsAvailable.setSelected(true);
        cmbIsAvailable.setEnabled(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new JPanel();
        btnBack = new JButton();
        btnCheckOut = new JButton();
        jPanel5 = new JPanel();
        lblISBN = new JLabel();
        btnSearchBook = new JButton();
        txtTitle = new JLabel();
        txtCopyNum = new JTextField();
        cmbIsAvailable = new JCheckBox();
        lblTitle = new JLabel();
        lblCopyNum = new JLabel();
        lblIsAvailable = new JLabel();
        txtSearchBook = new JTextField("48-56882");
        jPanel22 = new JPanel();
        jTable1 = new JTable();
        lblMember = new JLabel();
        btnSearchMember = new JButton();
        jScrollPane1 = new JScrollPane();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(BorderFactory.createTitledBorder(
        		new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Checkout Book",
        		javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
        		new java.awt.Font("Tahoma", 0, 24))); // NOI18N


        jPanel22.setBorder(BorderFactory
                .createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true)));

        jTable1.setBorder(BorderFactory.createTitledBorder(""));
        jTable1 = setTableModel(ROWS_EMPTY, COLUMNS);
        jScrollPane1.setViewportView(jTable1);

        GroupLayout jPanel22Layout = new GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);

        jPanel22Layout
                .setHorizontalGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel22Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
                                        GroupLayout.PREFERRED_SIZE, 537, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap()));
        jPanel22Layout.setVerticalGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(jPanel22Layout.createSequentialGroup().addContainerGap()
                        .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
                        .addContainerGap()));

        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnCheckOut.setText("Save Copy");
        btnCheckOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveCopyActionPerformed(evt);
            }
        });

        jPanel5.setBorder(BorderFactory.createTitledBorder(BorderFactory.
        		createLineBorder(new java.awt.Color(0, 0, 0), 2), "Book Details", javax.swing.border.TitledBorder.
        		DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        lblISBN.setText("ISBN ");

        btnSearchBook.setText("Search");
        btnSearchBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchBookActionPerformed(evt);
            }
        });

        txtTitle.setText("");

        lblTitle.setText("Title");
        lblCopyNum.setText("CopyNum");
        lblIsAvailable.setText("Available");

        GroupLayout jPanel5Layout = new GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(lblISBN)
                        .addGap(18, 18, 18)
                        .addComponent(txtSearchBook, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchBook))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(lblTitle)
                        )
                        .addGap(32, 32, 32)
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(txtTitle)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(lblCopyNum)
                        )
                        .addGap(32, 32, 32)
                        .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(txtCopyNum)))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(lblIsAvailable)
                                )
                                .addGap(32, 32, 32)
                                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(cmbIsAvailable)))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(lblIsAvailable)
                                )
                                .addGap(32, 32, 32)
                                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(btnCheckOut)))
                )
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblISBN)
                    .addComponent(txtSearchBook, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchBook))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTitle)
                    .addComponent(txtTitle)
                        .addGap(50, 50, 50))
                    .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCopyNum)
                    .addComponent(txtCopyNum)
                    )
                    .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIsAvailable)
                    .addComponent(cmbIsAvailable)
                    )
                    .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIsAvailable)
                    .addComponent(btnCheckOut)
                    )
                .addContainerGap()
            )
        );

        GroupLayout jPanel3Layout = new GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jPanel5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)

                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel22, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(btnBack)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel22, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)

                .addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                )
                .addContainerGap())
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jPanel3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jPanel3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private JTable setTableModel(Object[][] rows, String[] columns){
        jTable1.setModel( new javax.swing.table.DefaultTableModel(rows,columns));
        return jTable1;
    }

    private void displaytable() {

        HashMap<String, BookCopy> allRecords = controller.getBookCopyByIsbn(selectedBook.getIsbn());
        Object[][] rows = new Object[allRecords.size()][3];

        int counter = 0;

        for(BookCopy record : allRecords.values()) {
            rows[counter][0] = record.getIsbn();
            rows[counter][1] = record.getCopyNum();
            rows[counter][2] = record.isAvailable();

            counter++;
        }
        setTableModel(rows, COLUMNS);

    }

    private void btnSaveCopyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveCopyActionPerformed
        /**
         * here we add a new copy per selected Book
         * a book copy will have isbn, bookCopyId, copyNum, isAvailable
         */
        if(txtCopyNum.getText().equals("")){
            JOptionPane.showMessageDialog(new JFrame(), "The Copy Number field cannot be left blank.", "Message" , JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        else if(!isNumeric(txtCopyNum.getText())){
            JOptionPane.showMessageDialog(new JFrame(), "Only Numeric Values are allowed.", "Message" , JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        else if(selectedBook == null){
            JOptionPane.showMessageDialog(new JFrame(), "You need to select Book First.", "Message" , JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String bookCopyId = ""+Math.round(Math.random()*(10000000-10000+1)+10000);

        BookCopy copy = new BookCopy(bookCopyId, selectedBook.getIsbn(), Integer.parseInt(txtCopyNum.getText()), true);
        controller.saveNewBookCopy(copy);
        HashMap<String, BookCopy> allBookCopies = controller.readBookCopyMap();

        JOptionPane.showMessageDialog(new JFrame(), "Member Added Successfully !", "Message",
                JOptionPane.INFORMATION_MESSAGE);

        displaytable();
        cleanUpForm();
    }

    private void cleanUpForm(){
        txtCopyNum.setText("");
    }

    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        
        LibrarySystem.INSTANCE.setVisible(true);
        this.dispose();
    }

    private void btnSearchBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchBookActionPerformed
        selectedBook = null;
        if ( txtSearchBook.getText().isEmpty() ){
            txtTitle.setText( "" );
            JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message" , JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            
            try{
                Book book = controller.getBookByIsbn(txtSearchBook.getText());
                if(book == null){
                    txtTitle.setText( "" );
                    JOptionPane.showMessageDialog(new JFrame(), "No Book found with the specified ISBN.", "Message" , JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    selectedBook = book;
                    txtTitle.setText( book.getTitle() );
                    displaytable();
                }
           
            } catch(Exception e) {e.printStackTrace();}
           
        }
        
    }//GEN-LAST:event_btnSearchBookActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private JButton btnSearchBook;
    private JButton btnSearchMember;
    private JButton btnBack;
    private JButton btnCheckOut;
    private JLabel lblISBN;
    private JLabel lblMember;
    private JLabel lblTitle;
    private JLabel lblCopyNum;
    private JLabel lblIsAvailable;
    private JLabel txtTitle;
    private JTextField txtCopyNum;
    private JCheckBox cmbIsAvailable;
    private JPanel jPanel22;
    private JPanel jPanel3;
    private JPanel jPanel5;
    private JTextField txtSearchBook;
    private JTable jTable1;
    private JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isInitialized() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void isInitialized(boolean val) {
		// TODO Auto-generated method stub
		
	}
}
