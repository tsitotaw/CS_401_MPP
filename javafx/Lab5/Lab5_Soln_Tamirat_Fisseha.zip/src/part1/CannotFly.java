package part1;

public class CannotFly implements FlyBehavior {
	public void ﬂy() {
		System.out.println("I can’t ﬂy");
	}
}
