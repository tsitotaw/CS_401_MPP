package prob4;

public class House {
	private double lotSize;	
	
	public House(double lotSize) {
		this.lotSize = lotSize;
	}
	
	public double computeRent() {
		return 0.1 * this.lotSize;
	}
	
	public double getLotSize() {
		return lotSize;
	}
	public void setLotSize(double lotSize) {
		this.lotSize = lotSize;
	}
	
	@Override
	public String toString() {
		return "House [lotSize=" + lotSize + "]";
	}
}
