package librarysystem;

import business.LibraryMember;
import business.SystemController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import javax.swing.*;
//import net.proteanit.sql.DbUtils;

public class AddNewMemberWindow extends javax.swing.JFrame implements LibWindow {

	static Connection c;

	private static String[] COLUMNS = { "Model Id", "First Name", "Last Name", "Phone" };
	private static Object[][] ROWS_EMPTY = {{}};
	public AddNewMemberWindow() {
		initComponents();
		setTitle("Library Management System");
		setResizable(false);
		setLocationRelativeTo(null);
		jTable1.setEnabled(false);
		displaytable();

	}

	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		lblLastName = new javax.swing.JLabel();
		txtMemberId = new javax.swing.JTextField();
		lblPhone = new javax.swing.JLabel();
		txtLastName = new javax.swing.JTextField();
		btnBack = new javax.swing.JButton();
		btnSave = new javax.swing.JButton();
		txtFirstName = new javax.swing.JTextField();
		lblMemberId = new javax.swing.JLabel();
		lblFirstName = new javax.swing.JLabel();
		txtPhone = new javax.swing.JTextField();
		jPanel2 = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTable1 = new javax.swing.JTable();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(
				javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2), "New Member",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Tahoma", 0, 24))); // NOI18N

		lblLastName.setText("Branch");

		lblPhone.setText("Email");

		btnBack.setText("BACK");
		btnBack.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnBackActionPerformed(evt);
			}
		});

		btnSave.setText("ADD New Member");
		btnSave.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnSaveActionPerformed(evt);
			}
		});

		lblMemberId.setText("Member ID");

		lblFirstName.setText("First Name");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap(43, Short.MAX_VALUE)
						.addComponent(btnSave).addGap(52, 52, 52).addComponent(btnBack).addGap(54, 54, 54))
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(lblMemberId)
								.addComponent(lblFirstName)
								.addComponent(lblLastName)
								.addComponent(lblPhone)
						)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)

								.addComponent(txtMemberId, 0, 197, Short.MAX_VALUE)
								.addComponent(txtFirstName)
								.addComponent(txtLastName)
								.addComponent(txtPhone)
						)
						.addGap(30, 30, 30)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblMemberId).addComponent(txtMemberId, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblFirstName).addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)

						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblLastName).addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblPhone).addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(39, 39, 39)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(btnSave).addComponent(btnBack))
						.addContainerGap(31, Short.MAX_VALUE)));

		jPanel2.setBorder(javax.swing.BorderFactory
				.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true)));

		jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
		jTable1 = setTableModel(ROWS_EMPTY, COLUMNS);
		jScrollPane1.setViewportView(jTable1);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap()));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
						.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(35, 35, 35)
						.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(45, 45, 45)
						.addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(35, 35, 35)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(40, 40, 40)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap(35, Short.MAX_VALUE)));

		pack();
	}

	private JTable setTableModel(Object[][] rows, String[] columns){
		jTable1.setModel( new javax.swing.table.DefaultTableModel(rows,columns));
		return jTable1;
	}

	private void displaytable() {

		SystemController s = new SystemController();
		HashMap<String, LibraryMember> allMembers = s.readMemberMap();
		Object[][] rows = new Object[allMembers.size()][4];

		int counter = 0;

		for(LibraryMember member : allMembers.values()) {
			rows[counter][0] = member.getMemberId();
			rows[counter][1] = member.getFirstName();
			rows[counter][2] = member.getLastName();
			rows[counter][3] = member.getTelephone();
			counter++;
		}
		setTableModel(rows, COLUMNS);

	}

	private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {
		LibrarySystem.INSTANCE.setVisible(true);
		this.dispose();
	}

	private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {

		if (txtMemberId.getText().isEmpty() || txtFirstName.getText().isEmpty() || txtLastName.getText().isEmpty()
				|| txtPhone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message",
					JOptionPane.INFORMATION_MESSAGE);
		}
		else {
			try {
				String memberId = txtMemberId.getText();
				String fName = txtFirstName.getText();
				String lName = txtLastName.getText();
				String phone = txtPhone.getText();

				SystemController s = new SystemController();

				LibraryMember member = new LibraryMember(memberId, fName, lName, phone, null);
				s.saveNewMember(member);
				displaytable();
				JOptionPane.showMessageDialog(new JFrame(), "Member Added Successfully !", "Message",
						JOptionPane.INFORMATION_MESSAGE);

				txtMemberId.setText("");
				txtFirstName.setText("");
				txtLastName.setText("");
				txtPhone.setText("");
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "Message", JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	private javax.swing.JButton btnSave;
	private javax.swing.JButton btnBack;
	private javax.swing.JLabel lblMemberId;
	private javax.swing.JLabel lblFirstName;
	private javax.swing.JLabel lblLastName;
	private javax.swing.JLabel lblPhone;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTable jTable1;
	private javax.swing.JTextField txtMemberId;
	private javax.swing.JTextField txtFirstName;
	private javax.swing.JTextField txtLastName;
	private javax.swing.JTextField txtPhone;

	@Override
	public void init() {
	}

	@Override
	public boolean isInitialized() {
		return false;
	}

	@Override
	public void isInitialized(boolean val) {
	}
}
