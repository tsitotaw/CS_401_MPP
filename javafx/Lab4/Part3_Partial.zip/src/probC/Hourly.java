package probC;

public class Hourly extends Employee{

	private int hourlyWage;
	private int hoursPerWeek;
	
	@Override
	Double calcGrossPay(int month, int year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcCompensation(int month, int year) {		
		return 0.0;
	}
}
