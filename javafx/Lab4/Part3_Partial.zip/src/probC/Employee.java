package probC;

public abstract class Employee {
	private int empId;
	
	public void print() {
		
	}
	
	public Double calcCompensation(int month, int year) {
		return null;
	}
	
	abstract Double calcGrossPay(int month, int year);
}
