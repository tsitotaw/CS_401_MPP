package librarysystem;

import business.Author;
import business.LibraryMember;
import business.SystemController;
import dataaccess.Auth;

import javax.swing.*;
import java.sql.Connection;
import java.util.HashMap;
//import net.proteanit.sql.DbUtils;

public class AddAuthorWindow extends JFrame implements LibWindow {

	static Connection c;

	private static String[] COLUMNS = { "First Name", "Last Name", "Telephone", "Bio" };
	private static Object[][] ROWS_EMPTY = {{}};
	public AddAuthorWindow() {
		initComponents();
		setTitle("Manage Author");
		setResizable(false);
		setLocationRelativeTo(null);
		jTable1.setEnabled(false);
		displaytable();

	}

	private void initComponents() {

		jPanel1 = new JPanel();
		lblBio = new JLabel();
		txtFirstName = new JTextField();
		lblPhone = new JLabel();
		txtBio = new JTextArea(4,5);
		btnBack = new JButton();
		btnSave = new JButton();
		txtLastName = new JTextField();
		lblFirstName = new JLabel();
		lblLastName = new JLabel();
		txtPhone = new JTextField();
		jPanel2 = new JPanel();
		jScrollPane1 = new JScrollPane();
		jTable1 = new JTable();

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2), "New Author",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Tahoma", 0, 24))); // NOI18N

		lblBio.setText("Bio");

		lblPhone.setText("Phone");

		btnBack.setText("BACK");
		btnBack.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnBackActionPerformed(evt);
			}
		});

		btnSave.setText("ADD New Author");
		btnSave.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnSaveActionPerformed(evt);
			}
		});

		lblFirstName.setText("First Name");

		lblLastName.setText("Last Name");

		GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap(43, Short.MAX_VALUE)
						.addComponent(btnSave).addGap(52, 52, 52).addComponent(btnBack).addGap(54, 54, 54))
				.addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(lblFirstName)
								.addComponent(lblLastName)
								.addComponent(lblBio)
								.addComponent(lblPhone)
						)
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)

								.addComponent(txtFirstName, 0, 197, Short.MAX_VALUE)
								.addComponent(txtLastName)
								.addComponent(txtBio)
								.addComponent(txtPhone)
						)
						.addGap(30, 30, 30)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(lblFirstName).addComponent(txtFirstName, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(lblLastName).addComponent(txtLastName, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)

						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(lblBio).addComponent(txtBio, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(lblPhone).addComponent(txtPhone, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(39, 39, 39)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(btnSave).addComponent(btnBack))
						.addContainerGap(31, Short.MAX_VALUE)));

		jPanel2.setBorder(BorderFactory
				.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true)));

		jTable1.setBorder(BorderFactory.createTitledBorder(""));
		jTable1 = setTableModel(ROWS_EMPTY, COLUMNS);
		jScrollPane1.setViewportView(jTable1);

		GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
										GroupLayout.PREFERRED_SIZE, 537, GroupLayout.PREFERRED_SIZE)
								.addContainerGap()));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
						.addContainerGap()));

		GroupLayout layout = new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(35, 35, 35)
						.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGap(45, 45, 45)
						.addComponent(jPanel2, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGap(35, 35, 35)));
		layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(40, 40, 40)
						.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
								.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(jPanel2, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addContainerGap(35, Short.MAX_VALUE)));

		pack();
	}

	private JTable setTableModel(Object[][] rows, String[] columns){
		jTable1.setModel( new javax.swing.table.DefaultTableModel(rows,columns));
		return jTable1;
	}

	private void displaytable() {

		SystemController s = new SystemController();
		HashMap<String, Author> allAuthors = s.readAuthorsMap();
		if(allAuthors == null){
			return;
		}
		Object[][] rows = new Object[allAuthors.size()][4];

		int counter = 0;

		for(Author author : allAuthors.values()) {
			rows[counter][0] = author.getFirstName();
			rows[counter][1] = author.getLastName();
			rows[counter][2] = author.getTelephone();
			rows[counter][3] = author.getBio();
			counter++;
		}
		setTableModel(rows, COLUMNS);

	}

	private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {
		LibrarySystem.INSTANCE.setVisible(true);
		this.dispose();
	}

	private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {

		if (txtFirstName.getText().isEmpty()) {
			JOptionPane.showMessageDialog(new JFrame(), "First Name is required.", "Message",
					JOptionPane.INFORMATION_MESSAGE);
		}
		else {
			try {
				String firstName = txtFirstName.getText();
				String lastName = txtLastName.getText();
				String bio = txtBio.getText();
				String phone = txtPhone.getText();

				SystemController s = new SystemController();
				String authorId = ""+Math.round(Math.random()*(10000000-10000+1)+10000);
				Author author = new Author(authorId, firstName, lastName, bio, null, bio);
				s.saveNewAuthor(author);

				displaytable();
				JOptionPane.showMessageDialog(new JFrame(), "Author Added Successfully !", "Message",
						JOptionPane.INFORMATION_MESSAGE);

				txtFirstName.setText("");
				txtLastName.setText("");
				txtBio.setText("");
				txtPhone.setText("");
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "Message", JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	private JButton btnSave;
	private JButton btnBack;
	private JLabel lblFirstName;
	private JLabel lblLastName;
	private JLabel lblBio;
	private JLabel lblPhone;
	private JPanel jPanel1;
	private JPanel jPanel2;
	private JScrollPane jScrollPane1;
	private JTable jTable1;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextArea txtBio;
	private JTextField txtPhone;

	@Override
	public void init() {
	}

	@Override
	public boolean isInitialized() {
		return false;
	}

	@Override
	public void isInitialized(boolean val) {
	}
}
