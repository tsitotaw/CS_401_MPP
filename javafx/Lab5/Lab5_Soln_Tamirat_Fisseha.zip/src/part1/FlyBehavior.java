package part1;

public interface FlyBehavior {
	public void ﬂy();
}
