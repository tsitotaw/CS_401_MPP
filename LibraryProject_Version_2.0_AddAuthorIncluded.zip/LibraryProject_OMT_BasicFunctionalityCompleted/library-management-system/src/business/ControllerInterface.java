package business;

import java.util.HashMap;
import java.util.List;
public interface ControllerInterface {
	public void login(String id, String password) throws LoginException;
	public List<String> allMemberIds();
	public HashMap<String, LibraryMember> readMemberMap();
	public HashMap<String, Author> readAuthorsMap();
	public HashMap<String, CheckoutRecordEntry> readCheckoutRecordEntryHashMap();
	public HashMap<String, CheckoutRecord> readCheckoutRecordHashMap();
	public HashMap<String, Book> readBookMap();
	public HashMap<String, BookCopy> readBookCopyMap();
	public List<String> allBookIds();
	public Book getBookByIsbn(String isbn);
	public LibraryMember getMemberByMemberId(String memberId);
	public HashMap<String,BookCopy> getBookCopyByIsbn(String isbn);
	public BookCopy getAvailableBookCopyByIsbn(String isbn);
	public HashMap<String, CheckoutRecord> getCheckoutRecordByMemberId(String memberId);
	public CheckoutRecordEntry getCheckoutRecordEntryByEntryId(String entryId);
	public void saveNewBookCopy(BookCopy copy);
	public void saveNewMember(LibraryMember member);
	public void saveNewCheckoutRecordEntry(CheckoutRecordEntry entry);
	public void saveNewBook(Book book);
	public void saveNewAuthor(Author author);
	public void saveNewCheckoutRecord(CheckoutRecord record);
}
