package part1;

public interface QuackBehavior {
	public void quack();
}
