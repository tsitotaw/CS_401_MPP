package business;

import java.io.Serializable;
import java.util.List;

final public class CheckoutRecord implements Serializable {
	private LibraryMember member;
	private List<CheckoutRecordEntry> checkoutRecordEntries;

	public CheckoutRecord(LibraryMember member, List<CheckoutRecordEntry> checkoutRecordEntries) {
		this.member = member;
		this.checkoutRecordEntries = checkoutRecordEntries;
	}

	public LibraryMember getMember() {
		return member;
	}

	public void setMember(LibraryMember member) {
		this.member = member;
	}

	public List<CheckoutRecordEntry> getCheckoutRecordEntries() {
		return checkoutRecordEntries;
	}

	public void setCheckoutRecordEntries(List<CheckoutRecordEntry> checkoutRecordEntries) {
		this.checkoutRecordEntries = checkoutRecordEntries;
	}

	private static final long serialVersionUID = -2226197306790714013L;
}
