package business;

import java.util.HashMap;
import java.util.List;
public interface ControllerInterface {
	public void login(String id, String password) throws LoginException;
	public List<String> allMemberIds();
	public HashMap<String, LibraryMember> readMemberMap();
	public HashMap<String, CheckoutRecordEntry> readCheckoutRecordEntryHashMap();
	public HashMap<String, Book> readBookMap();
	public List<String> allBookIds();
	public Book getBookByIsbn(String isbn);
	public LibraryMember getMemberByMemberId(String memberId);
	public void saveNewMember(LibraryMember member);
	public void saveNewCheckoutRecordEntry(CheckoutRecordEntry entry);
}
