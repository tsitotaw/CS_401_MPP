package librarysystem;

import business.Address;
import business.LibraryMember;
import business.SystemController;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import javax.swing.*;
//import net.proteanit.sql.DbUtils;

public class AddNewMemberWindow extends javax.swing.JFrame implements LibWindow {

	static Connection c;

	private static String[] COLUMNS = { "Model Id", "First Name", "Last Name", "Phone", "Address"};
	private static Object[][] ROWS_EMPTY = { {} };

	public AddNewMemberWindow() {
		initComponents();
		setTitle("Manage Library Member");
		setResizable(false);
		setLocationRelativeTo(null);
		jTable1.setEnabled(false);
		displaytable();

	}

	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		lblMemberId = new javax.swing.JLabel();
		txtMemberId = new javax.swing.JTextField();
		lblFirstName = new javax.swing.JLabel();
		txtFirstName = new javax.swing.JTextField();
		lblLastName = new javax.swing.JLabel();
		txtLastName = new javax.swing.JTextField();
		lblPhone = new javax.swing.JLabel();
		txtPhone = new javax.swing.JTextField();
		lblAddressTitle = new javax.swing.JLabel();
		lblStreet = new javax.swing.JLabel();
		lblCity = new javax.swing.JLabel();
		lblState = new javax.swing.JLabel();
		txtStreet = new javax.swing.JTextField();
		txtCity = new javax.swing.JTextField();
		txtState = new javax.swing.JTextField();
		lblZip = new javax.swing.JLabel();
		txtZip = new javax.swing.JTextField();
		jTable1 = new javax.swing.JTable();
		btnSave = new javax.swing.JButton();
		btnBack = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(
				javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2), "New Member",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Tahoma", 0, 24))); // NOI18N

		lblMemberId.setText("Member ID");

		lblFirstName.setText("First Name");

		lblLastName.setText("Last Name");

		lblPhone.setText("Phone");

		lblAddressTitle.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
		lblAddressTitle.setText("ADDRESS DETAILS");

		lblStreet.setText("Street");

		lblCity.setText("City");

		lblState.setText("State");

		lblZip.setText("Zip");
		btnBack.setText("BACK");
		btnBack.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnBackActionPerformed(evt);
			}
		});

		btnSave.setText("ADD New Member");
		btnSave.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnSaveActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(47, 47, 47).addGroup(jPanel1Layout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
								.addComponent(lblState, javax.swing.GroupLayout.PREFERRED_SIZE, 54,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(lblAddressTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 198,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(jPanel1Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING,
																false)
														.addComponent(txtStreet, javax.swing.GroupLayout.DEFAULT_SIZE,
																114, Short.MAX_VALUE)
														.addComponent(txtState))
												.addComponent(btnSave)).addGap(18, 18, 18)
												.addGroup(jPanel1Layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(btnBack)
														.addGroup(jPanel1Layout.createSequentialGroup()
																.addGroup(jPanel1Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.TRAILING)
																		.addComponent(lblZip,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				30,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(lblCity,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				29,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addGroup(jPanel1Layout.createParallelGroup(
																		javax.swing.GroupLayout.Alignment.LEADING,
																		false)
																		.addComponent(txtCity,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				110, Short.MAX_VALUE)
																		.addComponent(txtZip))))))
								.addGap(20, 20, 20))
						.addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(lblStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 54,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(lblPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 80,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(lblLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 80,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(21, 21, 21)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
												.addComponent(txtLastName, javax.swing.GroupLayout.DEFAULT_SIZE, 299,
														Short.MAX_VALUE)
												.addComponent(txtPhone)))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addComponent(lblFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 91,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 299,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addComponent(lblMemberId, javax.swing.GroupLayout.PREFERRED_SIZE, 91,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(txtMemberId, javax.swing.GroupLayout.PREFERRED_SIZE, 299,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(20, Short.MAX_VALUE)))));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblMemberId)
								.addComponent(txtMemberId, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblFirstName)
								.addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblLastName).addComponent(txtLastName,
										javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(lblPhone).addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(18, 18, 18).addComponent(lblAddressTitle).addGap(19, 19, 19)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(txtCity, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(lblCity).addComponent(lblStreet))
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(
										jPanel1Layout.createSequentialGroup().addGap(18, 18, 18).addComponent(lblState))
								.addGroup(jPanel1Layout.createSequentialGroup()
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(jPanel1Layout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(txtZip, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(txtState, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(lblZip))))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(btnSave).addComponent(btnBack))
						.addContainerGap()));
		jPanel2.setBorder(javax.swing.BorderFactory
				.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true)));
		jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
		jTable1 = setTableModel(ROWS_EMPTY, COLUMNS);
		jScrollPane1.setViewportView(jTable1);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap()));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
						.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(35, 35, 35)
						.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(45, 45, 45)
						.addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(35, 35, 35)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(40, 40, 40)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap(35, Short.MAX_VALUE)));

		pack();
	}
	

	private JTable setTableModel(Object[][] rows, String[] columns) {
		jTable1.setModel(new javax.swing.table.DefaultTableModel(rows, columns));
		return jTable1;
	}

	private void displaytable() {

		SystemController s = new SystemController();
		HashMap<String, LibraryMember> allMembers = s.readMemberMap();
		Object[][] rows = new Object[allMembers.size()][5];

		int counter = 0;

		for (LibraryMember member : allMembers.values()) {
			rows[counter][0] = member.getMemberId();
			rows[counter][1] = member.getFirstName();
			rows[counter][2] = member.getLastName();
			rows[counter][3] = member.getTelephone();
			rows[counter][4] = member.getAddress();
			counter++;
		}
		setTableModel(rows, COLUMNS);

	}

	private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {
		LibrarySystem.INSTANCE.setVisible(true);
		this.dispose();
	}

	private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {

		if (txtMemberId.getText().isEmpty() || txtFirstName.getText().isEmpty() || txtLastName.getText().isEmpty()
				|| txtPhone.getText().isEmpty() || txtStreet.getText().isEmpty() || txtCity.getText().isEmpty()
				|| txtState.getText().isEmpty() || txtZip.getText().isEmpty()) {
			JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			try {
				String memberId = txtMemberId.getText();
				String fName = txtFirstName.getText();
				String lName = txtLastName.getText();
				String phone = txtPhone.getText();
				
				String street = txtStreet.getText();
				String city = txtCity.getText();
				String state = txtState.getText();
				String zip = txtZip.getText();

				SystemController s = new SystemController();
				Address addr = new Address(street, city, state, zip);
				LibraryMember member = new LibraryMember(memberId, fName, lName, phone, addr);
				
				s.saveNewMember(member);
				displaytable();
				JOptionPane.showMessageDialog(new JFrame(), "Member Added Successfully !", "Message",
						JOptionPane.INFORMATION_MESSAGE);

				txtMemberId.setText("");
				txtFirstName.setText("");
				txtLastName.setText("");
				txtPhone.setText("");
				txtStreet.setText("");
				txtCity.setText("");
				txtState.setText("");
				txtZip.setText("");
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "Message", JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	// Variables declaration - do not modify
	private javax.swing.JButton btnSave;
	private javax.swing.JButton btnBack;
	private javax.swing.JLabel lblMemberId;
	private javax.swing.JLabel lblFirstName;
	private javax.swing.JLabel lblLastName;
	private javax.swing.JLabel lblPhone;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JTextField txtMemberId;
	private javax.swing.JTextField txtFirstName;
	private javax.swing.JTextField txtLastName;
	private javax.swing.JTextField txtPhone;
	private javax.swing.JLabel lblAddressTitle;
	private javax.swing.JLabel lblCity;
	private javax.swing.JLabel lblState;
	private javax.swing.JLabel lblStreet;
	private javax.swing.JLabel lblZip;
	private javax.swing.JTextField txtCity;
	private javax.swing.JTextField txtState;
	private javax.swing.JTextField txtStreet;
	private javax.swing.JTextField txtZip;
	private javax.swing.JTable jTable1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	// End of variables declaration

	@Override
	public void init() {
	}

	@Override
	public boolean isInitialized() {
		return false;
	}

	@Override
	public void isInitialized(boolean val) {
	}
}
