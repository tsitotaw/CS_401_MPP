package business;

import java.io.Serializable;
import java.time.LocalDate;

final public class CheckoutRecordEntry implements Serializable {
	private String entryId;
	private LocalDate chkoutDate;
	private LocalDate dueDate;
	private String isbn;

	public CheckoutRecordEntry(String entryId, LocalDate chkoutDate, LocalDate dueDate, String isbn) {
		this.chkoutDate = chkoutDate;
		this.dueDate = dueDate;
		this.entryId = entryId;
		this.isbn = isbn;
	}

	public String getEntryId() {
		return entryId;
	}

	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}

	public LocalDate getChkoutDate() {
		return chkoutDate;
	}

	public void setChkoutDate(LocalDate chkoutDate) {
		this.chkoutDate = chkoutDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public String getBookId() {
		return isbn;
	}

	public void setBookId(String bookId) {
		this.isbn = bookId;
	}

	@Override
	public String toString() {
		return "CheckoutRecordEntry{" +
				"entryId='" + entryId + '\'' +
				", chkoutDate=" + chkoutDate +
				", dueDate=" + dueDate +
				", isbn='" + isbn + '\'' +
				'}';
	}

	private static final long serialVersionUID = -2226197316790714013L;
}
