package business;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.User;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	
	public void login(String id, String password) throws LoginException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, User> map = da.readUserMap();
		if(!map.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}
		String passwordFound = map.get(id).getPassword();
		if(!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();
		
	}
	
	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}

	@Override
	public HashMap<String, LibraryMember> readMemberMap() {
		DataAccess da = new DataAccessFacade();
		return da.readMemberMap();
	}

	@Override
	public HashMap<String, Author> readAuthorsMap() {
		DataAccess da = new DataAccessFacade();
		return da.readAuthorsMap();
	}

	@Override
	public HashMap<String, CheckoutRecordEntry> readCheckoutRecordEntryHashMap() {
		DataAccess da = new DataAccessFacade();
		return da.readCheckoutRecordEntriesMap();
	}

	@Override
	public HashMap<String, CheckoutRecord> readCheckoutRecordHashMap() {
		DataAccess da = new DataAccessFacade();
		return da.readCheckoutRecordsMap();
	}

	@Override
	public HashMap<String, Book> readBookMap() {
		DataAccess da = new DataAccessFacade();
		return da.readBooksMap();
	}

	@Override
	public HashMap<String, BookCopy> readBookCopyMap() {
		DataAccess da = new DataAccessFacade();
		return da.readBookCopyMap();
	}

	@Override
	public void saveNewMember(LibraryMember member) {
		DataAccess da = new DataAccessFacade();
		da.saveNewMember(member);
	}

	@Override
	public void saveNewCheckoutRecordEntry(CheckoutRecordEntry entry) {
		DataAccess da = new DataAccessFacade();
		da.saveNewCheckoutRecordEntry(entry);
	}


	@Override
	public void saveNewCheckoutRecord(CheckoutRecord record) {
		DataAccess da = new DataAccessFacade();
		da.saveNewCheckoutRecord(record);
	}

	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}

	@Override
	public Book getBookByIsbn(String isbn) {
		HashMap<String, Book> bookList = this.readBookMap();
		for(Book book : bookList.values()) {
			if(book.getIsbn().equals(isbn)){
				return book;
			}
		}
		return null;
	}

	@Override
	public LibraryMember getMemberByMemberId(String memberId) {
		HashMap<String, LibraryMember> memberList = this.readMemberMap();
		for(LibraryMember member : memberList.values()) {
			if(member.getMemberId().equals(memberId)){
				return member;
			}
		}
		return null;
	}

	@Override
	public HashMap<String, BookCopy> getBookCopyByIsbn(String isbn) {
		HashMap<String, BookCopy> copylist = this.readBookCopyMap();
		HashMap<String, BookCopy> recordList = new HashMap<>();
		if(copylist!= null) {
			for (BookCopy copy : copylist.values()) {
				if (copy.getIsbn().equals(isbn)) {
					recordList.put(copy.getBookCopyId(), copy);
				}
			}
		}
		return recordList;
	}

	@Override
	public BookCopy getAvailableBookCopyByIsbn(String isbn) {
		HashMap<String, BookCopy> copylist = this.readBookCopyMap();
		if(copylist!= null) {
			for (BookCopy copy : copylist.values()) {
				if (copy.getIsbn().equals(isbn) && copy.isAvailable()) {
					return copy;
				}
			}
		}
		return null;
	}

	@Override
	public HashMap<String, CheckoutRecord> getCheckoutRecordByMemberId(String memberId) {
		HashMap<String, CheckoutRecord> memberList = this.readCheckoutRecordHashMap();
		HashMap<String, CheckoutRecord> recordList = new HashMap<>();
		if(memberList!= null) {
			for (CheckoutRecord member : memberList.values()) {
				if (member.getMemberId().equals(memberId)) {
					recordList.put(member.getRecordId(), member);
				}
			}
		}
		return recordList;
	}

	@Override
	public CheckoutRecordEntry getCheckoutRecordEntryByEntryId(String entryId) {
		HashMap<String, CheckoutRecordEntry> entryList = this.readCheckoutRecordEntryHashMap();
		for(CheckoutRecordEntry entry : entryList.values()) {
			if(entry.getEntryId().equals(entryId)){
				return entry;
			}
		}
		return null;
	}


	@Override
	public void saveNewBookCopy(BookCopy copy) {
		DataAccess da = new DataAccessFacade();
		da.saveBookCopy(copy);
	}
	@Override
	public void saveNewBook(Book book) {
		DataAccess da = new DataAccessFacade();
		da.saveNewBook(book);
	}

	@Override
	public void saveNewAuthor(Author author) {
		DataAccess da = new DataAccessFacade();
		da.saveNewAuthor(author);
	}

	public void logout() {
		currentAuth = null;
		
	}


}
