package business;

import java.io.Serializable;
import java.util.List;

final public class CheckoutRecord implements Serializable {

	private String recordId;
	private String memberId;
	private String entryId;

	private LibraryMember member;
	private CheckoutRecordEntry entry;
	SystemController controller;

	public CheckoutRecord(String recordId, String memberId, String entryId) {
		this.recordId = recordId;
		this.memberId = memberId;
		this.entryId = entryId;
		//this.controller = new SystemController();
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getEntryId() {
		return entryId;
	}

	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}

	public LibraryMember getMember() {
		return member;
	}

	public void setMember(LibraryMember member) {
		this.member = member;
	}

	public CheckoutRecordEntry getEntry() {
		if(this.entryId != "" || this.entryId != null){
			SystemController controller = new SystemController();
			return controller.getCheckoutRecordEntryByEntryId(this.entryId);
		}
		return null;
	}

	public void setEntry(CheckoutRecordEntry entry) {
		this.entry = entry;
	}

	@Override
	public String toString() {
		return "CheckoutRecord{" +
				"recordId='" + recordId + '\'' +
				", memberId='" + memberId + '\'' +
				", entryId='" + entryId + '\'' +
				'}';
	}

	private static final long serialVersionUID = -2226197336790714013L;
}
