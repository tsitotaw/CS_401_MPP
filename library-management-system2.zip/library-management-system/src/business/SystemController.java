package business;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.User;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	
	public void login(String id, String password) throws LoginException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, User> map = da.readUserMap();
		if(!map.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}
		String passwordFound = map.get(id).getPassword();
		if(!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();
		
	}
	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}

	@Override
	public HashMap<String, LibraryMember> readMemberMap() {
		DataAccess da = new DataAccessFacade();
		return da.readMemberMap();
	}

	@Override
	public HashMap<String, CheckoutRecordEntry> readCheckoutRecordEntryHashMap() {
		DataAccess da = new DataAccessFacade();
		return da.readCheckoutRecordEntriesMap();
	}

	@Override
	public HashMap<String, Book> readBookMap() {
		DataAccess da = new DataAccessFacade();
		return da.readBooksMap();
	}

	@Override
	public void saveNewMember(LibraryMember member) {
		DataAccess da = new DataAccessFacade();
		da.saveNewMember(member);
	}

	@Override
	public void saveNewCheckoutRecordEntry(CheckoutRecordEntry entry) {
		DataAccess da = new DataAccessFacade();
		da.saveNewCheckoutRecordEntry(entry);
	}

	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}

	@Override
	public Book getBookByIsbn(String isbn) {
		HashMap<String, Book> bookList = this.readBookMap();
		for(Book book : bookList.values()) {
			if(book.getIsbn().equals(isbn)){
				return book;
			}
		}
		return null;
	}

	@Override
	public LibraryMember getMemberByMemberId(String memberId) {
		HashMap<String, LibraryMember> memberList = this.readMemberMap();
		for(LibraryMember member : memberList.values()) {
			if(member.getMemberId().equals(memberId)){
				return member;
			}
		}
		return null;
	}


}
