package exercise10;

public class Simple {
	boolean flag = false;
	
	Simple(boolean f) {
		flag = f;
	}
}