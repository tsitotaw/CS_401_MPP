package librarysystem;

import business.*;

import java.lang.reflect.Member;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

public class CheckoutBookWindow extends javax.swing.JFrame implements LibWindow {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    static Connection c;
    static String ISBN, SID;
    private Book selectedBook;
    private String selectedMemberId;
    private static String[] COLUMNS = { "Record Id", "Member Id", "Entry Id", "Checkout Date", "Due Date" };
    private static Object[][] ROWS_EMPTY = {{}};
    private SystemController controller = new SystemController();
    public CheckoutBookWindow() {
        initComponents();
        setTitle("Check Out Book");
        setResizable(false);
        setLocationRelativeTo(null);
        jTable1.setEnabled(false);
        ISBN = "";
        SID = "";

        lblCurrentDate.setText( new SimpleDateFormat("dd / MM / yyyy").format(new Date()) );

       /* try{
            Class.forName("com.mysql.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management_system", "root", "root");
        }
        catch(Exception e){e.printStackTrace();}*/
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        btnCheckOut = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        lblISBN = new javax.swing.JLabel();
        btnSearchBook = new javax.swing.JButton();
        txtTitle = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        txtSearchBook = new javax.swing.JTextField("48-56882");
        lblDate = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jTable1 = new javax.swing.JTable();
        txtSearchMember = new javax.swing.JTextField("1004");
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JLabel();
        lblMember = new javax.swing.JLabel();
        btnSearchMember = new javax.swing.JButton();
        lblCurrentDate = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(
                new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "Checkout Book",
                javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION,
                new java.awt.Font("Tahoma", 0, 24))); // NOI18N


        jPanel22.setBorder(javax.swing.BorderFactory
                .createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true)));

        jTable1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jTable1 = setTableModel(ROWS_EMPTY, COLUMNS);
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);

        jPanel22Layout
                .setHorizontalGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel22Layout.createSequentialGroup().addContainerGap().addComponent(jScrollPane1,
                                        javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap()));
        jPanel22Layout.setVerticalGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel22Layout.createSequentialGroup().addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
                        .addContainerGap()));

        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnCheckOut.setText("CHECKOUT BOOK");
        btnCheckOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckOutActionPerformed(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.
                createLineBorder(new java.awt.Color(0, 0, 0), 2), "Book Details", javax.swing.border.TitledBorder.
                DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        lblISBN.setText("ISBN ");

        btnSearchBook.setText("Search");
        btnSearchBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchBookActionPerformed(evt);
            }
        });

        txtTitle.setText("---");

        lblTitle.setText("Title");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addComponent(lblISBN)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtSearchBook, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnSearchBook))
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(lblTitle)
                                                )
                                                .addGap(32, 32, 32)
                                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(txtTitle))))
                                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblISBN)
                                        .addComponent(txtSearchBook, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSearchBook))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblTitle)
                                        .addComponent(txtTitle))
                                .addContainerGap())
        );

        lblDate.setText("Date");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(0, 0, 0), 2), "Member Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
                javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N

        lblName.setText("Name");

        txtName.setText("-tr--");

        lblMember.setText("Member ID");

        btnSearchMember.setText("Search");
        btnSearchMember.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchMemberActionPerformed(evt);
            }
        });

        // lblISBN5.setText("---");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblMember)
                                        .addComponent(lblName)
                                )
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(txtSearchMember, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnSearchMember))
                                        .addComponent(txtName)
                                )
                                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblMember)
                                        .addComponent(txtSearchMember, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnSearchMember))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(lblName)
                                        )
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(txtName)
                                        ))
                                .addContainerGap())
        );

        lblCurrentDate.setText("current_date_here");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(lblDate)
                                                .addGap(56, 56, 56)
                                                .addComponent(lblCurrentDate)
                                                .addGap(72, 72, 72))
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                                .addGap(35, 35, 35)
                                                .addComponent(btnCheckOut)
                                                .addGap(35, 35, 35)
                                                .addComponent(btnBack)))
                                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lblDate)
                                        .addComponent(lblCurrentDate))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnBack)
                                        .addComponent(btnCheckOut)
                                )
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSearchMemberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchMemberActionPerformed
        selectedMemberId = "";
        if ( txtSearchMember.getText().isEmpty() ){
            txtName.setText( "---" );
            JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message" , JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            LibraryMember member = controller.getMemberByMemberId(txtSearchMember.getText());

            if(member == null){
                txtName.setText( "---" );
                JOptionPane.showMessageDialog(new JFrame(), "No Member is found with the specified Id.", "Message" , JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                selectedMemberId = member.getMemberId();
                txtName.setText( member.getFirstName() + " " + member.getLastName() );
                displaytable();
            }
        }
    }

    private JTable setTableModel(Object[][] rows, String[] columns){
        jTable1.setModel( new javax.swing.table.DefaultTableModel(rows,columns));
        return jTable1;
    }

    private void displaytable() {

        HashMap<String, CheckoutRecord> allRecords = controller.getCheckoutRecordByMemberId(selectedMemberId);
        Object[][] rows = new Object[allRecords.size()][5];

        int counter = 0;

        for(CheckoutRecord record : allRecords.values()) {
            rows[counter][0] = record.getRecordId();
            rows[counter][1] = record.getMemberId();
            rows[counter][2] = record.getEntryId();
            rows[counter][3] = record.getEntry().getChkoutDate();
            rows[counter][4] = record.getEntry().getDueDate();
            counter++;
        }
        setTableModel(rows, COLUMNS);

    }

    private void btnCheckOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckOutActionPerformed

        if ( txtSearchBook.getText().isEmpty() || txtSearchMember.getText().isEmpty() ){
            JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message" , JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            /**
             * 1 - a new checkout record entry is created, containing the copy of the requested book and the checkout date and due date.
             * 2 - This checkout entry is then added to the member’s checkout record.
             * 3 - The copy that is checked out is marked as unavailable.
             * 4 - The updated checkout record is displayed on the UI and is also persisted.
             */

//            String bookCopyId = ""+Math.round(Math.random()*(10000000-10000+1)+10000);
//            BookCopy copy = new BookCopy(bookCopyId, selectedBook.getIsbn(), 5, true);
//            controller.saveNewBookCopy(copy);
            // check if the copy is available
            BookCopy copy = controller.getAvailableBookCopyByIsbn(selectedBook.getIsbn());
            if(copy == null){
                JOptionPane.showMessageDialog(new JFrame(), "No Copy is available.", "Message" , JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            copy.setAvailable(false);
            controller.saveNewBookCopy(copy);

            HashMap<String, BookCopy> allBookCopies = controller.readBookCopyMap();

            LocalDate checkOutDate = LocalDate.now();
            LocalDate dueDate = LocalDate.now().plusDays(selectedBook.getMaxCheckoutLength());
            String entryId = ""+Math.round(Math.random()*(10000000-10000+1)+10000);
            String isbn = selectedBook.getIsbn();

            CheckoutRecordEntry entry = new CheckoutRecordEntry(entryId, checkOutDate, dueDate, isbn);
            controller.saveNewCheckoutRecordEntry(entry);

            String recordId = ""+Math.round(Math.random()*(10000000-10000+1)+10000);
            CheckoutRecord record = new CheckoutRecord(recordId, selectedMemberId, entryId);
            controller.saveNewCheckoutRecord(record);

            HashMap<String, CheckoutRecordEntry> allEntries = controller.readCheckoutRecordEntryHashMap();
            HashMap<String, CheckoutRecord> allRecords = controller.readCheckoutRecordHashMap();

            /**
             * check the bookCopy with the bookId (isbn) and see if there is available item
             * if there is available item, subtract one from it and do the checkout
             * if not, notify user that there is no available item.
             *
             */

            JOptionPane.showMessageDialog(new JFrame(), "Member Added Successfully !", "Message",
                    JOptionPane.INFORMATION_MESSAGE);

            displaytable();
            cleanUpForm();
        }

    }

    private void cleanUpForm(){
        //selectedBook = null;
        //selectedMemberId = "";
        //txtName.setText("");
        //txtSearchBook.setText("");
        //txtTitle.setText("");
        //txtSearchMember.setText("");
    }

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        LibrarySystem.INSTANCE.setVisible(true);
        this.dispose();
    }

    private void btnSearchBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchBookActionPerformed
        selectedBook = null;
        if ( txtSearchBook.getText().isEmpty() ){
            txtTitle.setText( "---" );
            JOptionPane.showMessageDialog(new JFrame(), "The fields cannot be left blank.", "Message" , JOptionPane.INFORMATION_MESSAGE);
        }
        else{

            try{
                Book book = controller.getBookByIsbn(txtSearchBook.getText());
                if(book == null){
                    txtTitle.setText( "---" );
                    JOptionPane.showMessageDialog(new JFrame(), "No Book found with the specified ISBN.", "Message" , JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    selectedBook = book;
                    txtTitle.setText( book.getTitle() );
                }

            } catch(Exception e) {e.printStackTrace();}

        }

    }//GEN-LAST:event_btnSearchBookActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSearchBook;
    private javax.swing.JButton btnSearchMember;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCheckOut;
    private javax.swing.JLabel lblISBN;
    private javax.swing.JLabel lblMember;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel txtName;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblCurrentDate;
    private javax.swing.JLabel txtTitle;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JTextField txtSearchBook;
    private javax.swing.JTextField txtSearchMember;
    private javax.swing.JTable jTable1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void init() {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean isInitialized() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void isInitialized(boolean val) {
        // TODO Auto-generated method stub

    }
}
