package part2;

public interface Shape {
	double computeArea();
}
