package probC;

public class Salaried extends Employee{

	private Double salary;
	
	@Override
	Double calcGrossPay(int month, int year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcCompensation(int month, int year) {
		return 0.0;
	}
}
