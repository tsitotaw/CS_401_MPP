package part1;

public class Quack implements QuackBehavior {
	public void quack() {
		System.out.println("quacking");
	}
}
